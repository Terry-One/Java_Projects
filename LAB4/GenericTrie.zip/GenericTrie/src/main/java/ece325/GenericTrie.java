package ece325;

/**
 * Lab 4: Generics <br />
 * The {@code GenericTrie} class <br />
 * Reference: <a href="https://en.wikipedia.org/wiki/Trie">
 *              https://en.wikipedia.org/wiki/Trie
 *            </a>
 */
public class GenericTrie<K extends CharSequence, V> 
{
		
    /**
     * Root node of the Prefix Tree
     */	 
	TrieNode<V> root; 

    
    public void insert(K word, V value) {
    	// TODO: Insert a new element to the Prefix Tree
        
    }
    
    
    public V search(K word) {
    	// TODO: Returns the value associated with the word is in the Prefix Tree
    	return null;
    }
    
   
    public boolean startWith(K prefix) {
    	// TODO: Returns if there is any word in the Prefix Tree that starts with the given prefix.
    	return true;
    }

    public V remove(K word) {
    	// TODO: Removes an element from the Prefix Tree, returning its associated value
        
    }

}


