package ece325;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Unit test for GenericTrie
 */
public class GenericTrieDoubleTest 
{

    static String[] words = {"ece", "lab", "java", "jar", "car", "cat", "care", "laboratory", "ebook"};
    static Double[] values = {10.5, 2.0, 3.33, 0.35, -4.0, 42.001, 6.0, -1.02, 45.9}; 
    
    static GenericTrie<String, Double> trie = new GenericTrie<String, Double>();

    @BeforeClass
    public static void initTrie() 
    {
        for (int i = 0; i < words.length ; i++) 
			trie.insert(words[i], values[i]); 
    }

    @Test
    public void searchLab()
    {   
        // TODO: implement test
    }

    @Test
    public void searchJava()
    {   
        // TODO: implement test
    }

    @Test
    public void startWidthFalse()
    {   
        // TODO: implement test
    }

    @Test
    public void startWidthTrue()
    {   
        // TODO: implement test
    }
				
    @Test
    public void searchBook()
    {   
        // TODO: implement test
    }

    @Test
    public void removeInTrie()
    {   
        // TODO: implement test
    }

    public void removeNotInTrie()
    {   
        // TODO: implement test
    }

}
