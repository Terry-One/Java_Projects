/**
 * Assignment 7: Type Compatibility and Generics <br />
 * The {@code TwoDShape} interface
 */
public interface TwoDShape extends GeometricShape {
    public double area();
}
