/**
 * Assignment 7: Type Compatibility and Generics <br />
 * The {@code ThreeDShape} interface
 */
public interface ThreeDShape extends GeometricShape {
    public double volume();
}
