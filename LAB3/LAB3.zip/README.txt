Name: Terry Wan 
ID: 1586035
ECE 325 LAB3

The main program for deliverable 1 is in Demo1.java,
THe main program for deliverable 2 is in Demo2.java,
Part 3 is in BigNumbers.java.